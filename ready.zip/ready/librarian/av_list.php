<?php
//this file describe 1 link to document in list of documents

unset($_POST);
include_once ('connect_mysql.php');



$card_info = $pdo->query('SELECT * FROM document WHERE documentType=3 or documentType=4');

while ($row = $card_info->fetch()){

    $docId = $row['docId'];
    $url = "documentL.php?id=".$docId;
    $url_text = $row['title'];

    include ('doc_link.html');

}


?>