<?php
//page that edits information of User Card and puts changes into database

include_once('connect_mysql.php');

$id = $_GET['id'];

$card_info = $pdo->query("SELECT * FROM usercard WHERE cardId=$id");
$row = $card_info->fetch();
//создаю переменные для вывода в html файл
$cardId = $row['cardId'];
$name = $row['name'];
$surname = $row['surname'];
$email = $row['email'];
$phone = $row['phone'];

$url = 'cardEdit.php?id=' . $id;
$html = 0;

if (!isset($_POST['Name']) and !isset($_POST['Surname']) and !isset($_POST['Email']) and
    !isset($_POST['Number']) and !isset($_POST['Password1']) and !isset($_POST['Password2'])) {
    include('cardEdit.html');
}

if (isset($_POST['Name']) and isset($_POST['Surname']) and isset($_POST['Email']) and
    isset($_POST['Number']) and isset($_POST['Password1']) and isset($_POST['Password2'])) {
    if (strlen($_POST['Name']) > 0 or strlen($_POST['Surname']) > 0 or strlen($_POST['Email']) > 0 or
        strlen($_POST['Number']) > 0 or (strlen($_POST['Password1']) > 0 and strlen($_POST['Password2']) > 0)) {
        $html = 1;
    } else include('cardEdit.html');
}

if (isset($_POST['Name']))
    if (strlen($_POST['Name']) > 0)
        $pdo->query('UPDATE `usercard` SET `name`="' . $_POST['Name'] . '" WHERE cardId=' . $id);
if (isset($_POST['Surname']))
    if (strlen($_POST['Surname']) > 0)
        $pdo->query('UPDATE `usercard` SET `surname`="' . $_POST['Surname'] . '" WHERE cardId=' . $id);
if (isset($_POST['Email']))
    if (strlen($_POST['Email']) > 0)
        $pdo->query('UPDATE `usercard` SET `email`="' . $_POST['Email'] . '" WHERE cardId=' . $id);
if (isset($_POST['Number']))
    if (strlen($_POST['Number']) > 0)
        $pdo->query('UPDATE `usercard` SET `phone`="' . $_POST['Number'] . '" WHERE cardId=' . $id);
if (isset($_POST["usertype"])) {
    if ($_POST["usertype"] == "student") {
        $pdo->query('UPDATE `usercard` SET `userType`=0 WHERE cardId=' . $id);
    } else {
        $pdo->query('UPDATE `usercard` SET `userType`=1 WHERE cardId=' . $id);
    }
    $html = 1;
}

//проверка на совпадение пароля
if (isset($_POST['Password1']) and isset($_POST['Password2']))
    if (strlen($_POST['Password1']) > 2 and strlen($_POST['Password2']) > 2) {
        if ($_POST['Password1'] == $_POST['Password2'])
            $pdo->query('UPDATE `usercard` SET `password`="' . md5($_POST['Password1']) . '" WHERE cardId=' . $id);
    } elseif ($_POST['Password1'] != $_POST['Password2']) {
        echo 'passwords is not equal';
        $html = 0;
    }

if ($html == 1)
    include('succesfulEdit.html');


?>