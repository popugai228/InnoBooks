<?php

include_once ('connect_mysql.php');

$location = $_GET['loc'];
$id = $_GET['id'];

$pdo->query('DELETE FROM `copies` WHERE docId='.$id.' AND location="'.$location.'" LIMIT 1');

include ('delete_copy_successful.html');

?>