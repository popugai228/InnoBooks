<?php

include ('connect_mysql.php');

$id = $_GET['id'];
$url = "get_document.php?id=$id";


$card = $pdo->query("SELECT * FROM user WHERE cardId=$id");
$row = $card->fetch();

$currentDoc = $row['currentDoc'];

if (!isset($_POST['location'])) {

    $text = "";
    include_once ('set_location.html');

} elseif (!strlen($_POST['location'])) {

    $text = "location must be filled";
    include_once ('set_location.html');

} else {

    $location = $_POST['location'];
    $pdo->query('UPDATE `copies` SET `available`=1, `location`="' . $location . '" WHERE docId=' . $currentDoc . ' AND available=0 AND location="on hand" LIMIT 1');
    $pdo->query('UPDATE `user` SET `returnDate`="0000-00-00", `currentDoc`=0, `fine`=0 WHERE cardId=' . $id);
    // and put doc in list with "ex" documents of user

    $queue = $pdo->query("SELECT * FROM queue WHERE docId=$currentDoc");
    if ($q = $queue->fetch()) {

        $priority = $q['priority'];
        while ($q = $queue->fetch()) {
            if ($q['priority'] < $priority)
                $priority = $row['priority'];
        }

        $queue = $pdo->query("SELECT * FROM queue WHERE priority=$priority");
        $row = $queue->fetch();
        $userId = $row['cardId'];
        $pdo->query("UPDATE `user` SET `reservedDoc`=$currentDoc, `returnDate`=DATE_ADD(NOW(),Interval 1 DAY) WHERE cardId=$userId");
        $pdo->query('UPDATE `copies` SET `available`=0 WHERE docId='.$currentDoc.' AND available=1 AND location<>"on hand" LIMIT 1');
        $pdo->query("DELETE FROM `queue` WHERE priority=$priority");

        $card = $pdo->query("SELECT * FROM usercard WHERE cardId=$userId");
        $row = $card->fetch();
        $name = $row['name'];
        $surname = $row['surname'];

        $url = "user_card.php?id=$userId";
        $url_text = $name." ".$surname;
        include ('get_and_reserve.html');

    } else { # if no queue
        include('get_successful.html');
    }

}


?>