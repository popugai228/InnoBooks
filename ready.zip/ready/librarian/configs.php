<?php
//data for connecting with server and mysql
define('HOST', 'localhost');
define('USER', 'root');
define('PASSWORD', '');
define('NAME_BD', 'itp');
?>
