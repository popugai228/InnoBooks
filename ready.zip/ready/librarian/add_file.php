<?php
//page that puts the A/V material into database

include "connect_mysql.php";

if (!isset($_POST["title"]) and !isset($_POST["authors"])
    and !isset($_POST["location"]) and !isset($_POST["docType"])
    and !isset($_POST["price"])
    and !isset($_POST["location"])) {
    include_once "add_file.html";

} elseif (!strlen($_POST["title"]) or !strlen($_POST["authors"])
    or !strlen($_POST["location"]) or !strlen($_POST["docType"])
    or !strlen($_POST["price"])) {
    include_once "add_file.html";
    echo "All field must not be empty";
} else {
    $title = $_POST["title"];
    $authors = $_POST["authors"];
    $location = $_POST["location"];


    if ($_POST["docType"] == "video") {
        $docType = 3;
    } else {
        $docType = 4;
    }
    $isAvailable = 1;
    $price = $_POST["price"];
    if (!$pdo->query("SELECT * FROM `document` WHERE `title` LIKE '$title' AND `authors` LIKE '$authors'")->fetch()) {
        $pdo->query("INSERT INTO `document`(`title`, `authors`,`documentType`, `isAvailable`, `price`)
 VALUES ( '$title', '$authors', '$docType', '$isAvailable', '$price');");
    }


    $card_info = $pdo->query("SELECT * FROM `document` WHERE `title` LIKE '$title' AND `authors` LIKE '$authors'");
    $row = $card_info->fetch();

    $docId = $row["docId"];
    if (!strlen($_POST["copies"])) {
        $pdo->query("INSERT INTO `copies` (`docId`, `location`, `available`) VALUES ('$docId', '$location', '$isAvailable');");


    } else {
        $n = intval($_POST["copies"]);
        while ($n != 0) {
            $n--;
            $pdo->query("INSERT INTO `copies` (`docId`, `location`, `available`) VALUES ('$docId', '$location', '$isAvailable');");
        }
    }



    include("succesfulAddItem.html");


}


?>