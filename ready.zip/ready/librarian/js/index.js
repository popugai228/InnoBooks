// from - http://cssdeck.com/labs/ql8jmgjt 

function updateLog() {
  var one = $("#opt_1:checked").val() ? "On" : "Off"
  var two = $("#opt_2:checked").val() ? "On" : "Off"
  $(".log").html("Everyone: " + one + "<br/>Just for me: " + two)
}

$(".radio-group__option").change(updateLog)