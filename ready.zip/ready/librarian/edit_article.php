<?php
//page that puts the book into database

include "connect_mysql.php";
$sequence_of_fields=[];
$query ="";
$id = $_GET["id"];

if (!isset($_POST["date"]) and !isset($_POST["title"]) and !isset($_POST["authors"])
    and !isset($_POST["publisher"]) and !isset($_POST["issue"])
    and !isset($_POST["issueAuthors"]) and !isset($_POST["price"])) {
    include_once "edit_article.html";
}
else
{
    if($_POST["title"]!="")
    {
        $sequence_of_fields["title"] = $_POST["title"];
    }
    if($_POST["authors"]!="")
    {
        $sequence_of_fields["authors"] = $_POST["authors"];
    }
    if($_POST["publisher"]!="")
    {
        $sequence_of_fields["publishedBy"] = $_POST["publisher"];
    }
    if($_POST["date"]!="")
    {
        $sequence_of_fields["publicationDate"] = $_POST["date"];
    }
    if($_POST["issue"]!="")
    {
        $sequence_of_fields["edition"] = $_POST["issue"];
    }
    if($_POST["price"]!="")
    {
        $sequence_of_fields["price"] = $_POST["price"];
    }
    if($_POST["issueAuthors"]!="")
    {
        $sequence_of_fields["issueAuthors"] = $_POST["issueAuthors"];
    }
    $query="UPDATE `document` SET";
    foreach($sequence_of_fields as $key => $value)
    {
        $query=$query."`$key`=\"$value\", ";
    }
    $query=substr($query,0,-2)." WHERE docId=$id";
    $pdo->query($query);
    include ("articles_list.php");


}


?>
