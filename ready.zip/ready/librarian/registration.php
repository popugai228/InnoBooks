<?php
//this file allows to librarian add new users.

include_once ('connect_mysql.php');


if (!isset($_POST["name"]) and !isset($_POST["surname"]) and !isset($_POST["email"]) and !isset($_POST["number"])
    and !isset($_POST["password1"]) and !isset($_POST["password2"]) and !isset($_POST["usertype"])) {

    include_once "registration.html";

} elseif (!isset($_POST["name"]) or !isset($_POST["surname"]) or !isset($_POST["email"]) or !isset($_POST["number"])
    or !isset($_POST["password1"]) or !isset($_POST["password2"]) or !isset($_POST["usertype"])){

    if (!strlen($_POST["name"]) or !strlen($_POST["surname"]) or !strlen($_POST["email"]) or !strlen($_POST["number"])
        or !strlen($_POST["password1"]) or !strlen($_POST["password2"])) {

        include_once "registration.html";
        echo "All fields must not be empty";

    }

} elseif ($_POST["password1"] != $_POST["password2"]) {

        include_once "registration.html";
        echo "Passwords do not match. Please, write them again";

} else {

    $password = $_POST["password1"];
    $codedPassword = md5($password);
    $name = $_POST["name"];
    $surname = $_POST["surname"];
    $email = $_POST["email"];
    $phone = $_POST["number"];
    if ($_POST["usertype"] == "student")
        $usertype = 0;
    else
        $usertype = 1;

    $card_info = $pdo->query("SELECT * FROM `usercard` WHERE `email` LIKE '$email' AND `name` LIKE '$name' AND `surname` LIKE '$surname'");

    $isExist = false;
    if ($row = $card_info->fetch())
        if ($row["name"] == $name && $row["surname"] == $surname && $row["email"] == $email)
            $isExist = true;

    if ($isExist) {
        echo "That user already is in database.\n";
        include_once("registration.html");
    } else {
        $pdo->query("INSERT INTO `usercard` (`password`, `email`, `phone`, `name`, `surname`, `userType`) VALUES ('$codedPassword','$email','$phone','$name','$surname','$usertype')");
        $pdo->query("INSERT INTO `user`(`currentDoc`, `fine`, `reservedDoc`) VALUES (0,0,0)");

        $card_info = $pdo->query("SELECT * FROM `usercard` WHERE `email` LIKE '$email' AND `name` LIKE '$name' AND `surname` LIKE '$surname'");
        // Вытаскиваю значение кард айди для дальнейшего отображения его в successfully.html
        $row = $card_info->fetch();
        if ($row["name"] == $name && $row["surname"] == $surname)
            $cardId = $row["cardId"];

        include("successfully.html");
    }

}

?>