<?php
//returns list of users with reserved document

include_once ('connect_mysql.php');


//делаю запрос в БД
$user = $pdo->query("SELECT * FROM user WHERE reservedDoc <> 0 AND returnDate <> 0000-00-00");

while ($row = $user->fetch()){
    $user_id = $row['cardId'];
    $reservedDoc = $row['reservedDoc'];

    $card_info = $pdo->query("SELECT * FROM usercard WHERE cardId = $user_id");
    $r = $card_info->fetch();
    //создаю переменные для вывода в html файл
    $cardId = $r['cardId'];
    $name = $r['name'];
    $surname = $r['surname'];
    $url = "user_with_reservation.php?id=".$cardId; // add doc link
    $url_text = $name . " " . $surname;

    //вывожу html файл
    include ('user_link.html');

}


?>