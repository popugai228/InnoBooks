<?php
//this file describe 1 link to document in list of documents

unset($_POST);
include_once ('connect_mysql.php');

$id = $_GET['id'];

$card_info = $pdo->query('SELECT * FROM copies WHERE docId='.$id);

while ($row = $card_info->fetch()){

    $location = $row['location'];
    $available = $row['available'];

    // if который выбирает доступные для удаления книги
    if ($location!='on hand' and $available==1){
        $url = "delete_copy.php?loc=$location&id=$id";
        $url_text = $location;
        include ('doc_link.html');
    }


}


?>