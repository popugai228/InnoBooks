<?php
//calculates fine and returns the list of users with fine

include_once ('connect_mysql.php');

//calculate the fine of each debtor
$debtors = $pdo->query("SELECT * FROM user WHERE currentDoc <> 0 AND TO_DAYS(NOW()) - TO_DAYS(returnDate) > 1");
while ($row = $debtors->fetch()){
    $currentDoc = $row['currentDoc'];
    $document = $pdo->query("SELECT * FROM document WHERE docId=$currentDoc");
    $doc_row = $document->fetch();
    $price = $doc_row['price'];

    $returnDate = strtotime($row['returnDate']);
    $now = time(); // or your date as well
    $datediff = $now - $returnDate;
    $daydiff = round($datediff / (60 * 60 * 24));

    $fine = $daydiff * 100;
    if ($price < $fine) {
        $fine = $price;
    }

    $userId = $row['cardId'];

    $pdo->query("UPDATE `user` SET `fine`=$fine WHERE cardId=$userId");
}


#return list of users with fine
$user = $pdo->query("SELECT * FROM user WHERE fine <> 0");

while ($row = $user->fetch()){
    $user_id = $row['cardId'];

    $card_info = $pdo->query("SELECT * FROM usercard WHERE cardId = $user_id");
    $r = $card_info->fetch();
    //создаю переменные для вывода в html файл
    $name = $r['name'];
    $surname = $r['surname'];
    $fine = $row['fine'];
    $url = "#.php?id=".$user_id; // add doc link
    $url_text = $name . " " . $surname;


    include ('user_with_fine_link.html');

}


?>