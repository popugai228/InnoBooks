<?php
//returns list of users with document

include_once ('connect_mysql.php');


$user = $pdo->query("SELECT * FROM user WHERE currentDoc <> 0");

while ($row = $user->fetch()){
    $cardId = $row['cardId'];

    $card_info = $pdo->query("SELECT * FROM usercard WHERE cardId = $cardId");
    $r = $card_info->fetch();

    $name = $r['name'];
    $surname = $r['surname'];
    $url = "user_with_document.php?id=".$cardId;
    $url_text = $name . " " . $surname;


    include ('user_link.html');

}


?>