<?php
//returns information about document

include_once ('connect_mysql.php');

$docId = $_GET['id'];


$copies = $pdo->query("SELECT * FROM copies WHERE docId=$docId AND available=1");
$count = 0;
while ($row = $copies->fetch())
    $count = $count + 1;


$doc_info = $pdo->query("SELECT * FROM document WHERE docId=$docId");
$row = $doc_info->fetch();

$documentType = $row['documentType'];
$title = $row['title'];
$authors = $row['authors'];
$price = $row['price'];

$isAvailable = $row['isAvailable'];
if ($isAvailable == 0 or $count <= 1) {
    $isAvailable = 'No';
} else $isAvailable = 'Yes';

$url_copy = 'add_copy.php?id='.$docId;
$delete_url = 'delete_doc.php?id='.$docId;
$delete_copy_url = 'remove_copies.php?id='.$docId;


if ($documentType == 1) {

    $publicationDate = $row['publicationDate'];
    $publishedBy = $row['publishedBy'];
    $edition = $row['edition'];

    $edit_url = 'edit_book.php?id=' . $docId;
    include('book.html');

} elseif ($documentType == 2){

    $publicationDate = $row['publicationDate'];
    $journal = $row['publishedBy'];
    $issue = $row['edition'];
    $issueEditors = $row['issueAuthors'];

    $edit_url = 'edit_article.php?id='.$docId;
    include ('journal.html');

} else {

    $edit_url = 'edit_file.php?id='.$docId;
    include ('av_material.html');

}


?>