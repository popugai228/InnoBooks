<?php
//page that puts the article into database
include "connect_mysql.php";

if (!isset($_POST["date"]) and !isset($_POST["title"]) and !isset($_POST["authors"])
    and !isset($_POST["publisher"]) and !isset($_POST["issue"])
    and !isset($_POST["issueAuthors"]) and !isset($_POST["price"])
    and !isset($_POST["location"]) and !isset($_POST["copies"])) {
    include_once "add_article.html";

} elseif (!strlen($_POST["date"]) or !strlen($_POST["title"]) or !strlen($_POST["authors"])
    or !strlen($_POST["publisher"]) or !strlen($_POST["issue"])
    or !strlen($_POST["issueAuthors"]) or !strlen($_POST["price"])
    or !strlen($_POST["location"])) {
    include_once "add_article.html";
    echo "All field must not be empty";
} else {
    $title = $_POST["title"];
    $authors = $_POST["authors"];
    $issue = $_POST["issue"];
    $publisher = $_POST["publisher"];
    $issueAuthors = $_POST["issueAuthors"];
    $location = $_POST["location"];
    $docType = 2;
    $isAvailable = 1;
    $price = $_POST["price"];
    $date = $_POST['date'];
    if (!$pdo->query("SELECT * FROM `document` WHERE `title` LIKE '$title' AND `authors` LIKE '$authors'")->fetch()) {
        $pdo->query("INSERT INTO `document`(`title`, `authors`, `edition`, `publishedBy`, `documentType`, `isAvailable`, `price`,`issueAuthors`, `publicationDate`)
 VALUES ( '$title', '$authors', '$issue', '$publisher', '$docType', '$isAvailable', '$price', '$issueAuthors', '$date');");
    }


    $card_info = $pdo->query("SELECT * FROM `document` WHERE `title` LIKE '$title' AND `authors` LIKE '$authors'");
    $row = $card_info->fetch();

    $docId = $row["docId"];
    if (!strlen($_POST["copies"])) {
        $pdo->query("INSERT INTO `copies` (`docId`, `location`, `available`) VALUES ('$docId', '$location', '$isAvailable');");


    } else {
        $n = intval($_POST["copies"]);
        while ($n != 0) {
            $n--;
            $pdo->query("INSERT INTO `copies` (`docId`, `location`, `available`) VALUES ('$docId', '$location', '$isAvailable');");
        }
    }


    include("succesfulAddItem.html");


}


?>