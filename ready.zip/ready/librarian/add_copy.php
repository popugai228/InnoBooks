<?php
//page that puts the copy of book into database

include "connect_mysql.php";
$docId = $_GET['id'];

if (!isset($_POST["location"])) {
    include_once "add_copy.html";

} elseif (!strlen($_POST["location"])) {

    include_once "add_copy.html";
    echo "Location must not be empty";

} else {

    $location = $_POST["location"];
    $isAvailable = 1;
    $pdo->query("INSERT INTO `copies` (`docId`, `location`, `available`) VALUES ('$docId', '$location', '$isAvailable');");
    include("succesfulAddItem.html");

}


?>