<?php
//returns list of users

include_once ('connect_mysql.php');


//делаю запрос в БД
$card_info = $pdo->query('SELECT * FROM usercard');

while ($row = $card_info->fetch()){

    //создаю переменные для вывода в html файл
    $cardId = $row['cardId'];
    $name = $row['name'];
    $surname = $row['surname'];
    $url = "user_card.php?id=".$cardId;
    $url_text = $name . " " . $surname;

    //вывожу html файл
    include ('user_link.html');

}


?>