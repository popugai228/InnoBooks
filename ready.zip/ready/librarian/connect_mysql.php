<?php
//this file connects pages with database

include('configs.php');

//connecting to MySQL Data Base
$dsn = "mysql:host=" . HOST . ";dbname=" . NAME_BD . ";";
try {
$pdo = new PDO($dsn, USER, PASSWORD, [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
} catch (PDOException $e) {
die('DB error: ' . $e->getMessage());
}

?>