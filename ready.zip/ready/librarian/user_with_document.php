<?php
//returns information about user with document

include_once ('connect_mysql.php');

$id = $_GET['id'];

$card_info = $pdo->query("SELECT * FROM usercard WHERE cardId=$id");
$row = $card_info->fetch();


$debtor = $pdo->query("SELECT * FROM user WHERE cardId=$id AND currentDoc <> 0 AND TO_DAYS(NOW()) - TO_DAYS(returnDate) >= 1");
if ($r = $debtor->fetch()){
    $currentDoc = $r['currentDoc'];
    $document = $pdo->query("SELECT * FROM document WHERE docId=$currentDoc");
    $doc_row = $document->fetch();
    $price = $doc_row['price'];

    $returnDate = strtotime($r['returnDate']);
    $now = time();
    $datediff = $now - $returnDate;
    $daydiff = round($datediff / (60 * 60 * 24));

    $fine = $daydiff * 100;
    if ($price < $fine) {
        $fine = $price;
    }

    $userId = $r['cardId'];

    $pdo->query("UPDATE `user` SET `fine`=$fine WHERE cardId=$id");
}


$cardId = $row['cardId'];
$name = $row['name'];
$surname = $row['surname'];
$email = $row['email'];
$phone = $row['phone'];

$card = $pdo->query("SELECT * FROM user WHERE cardId=$id");
$row = $card->fetch();

$fine = $row['fine'];
$currentDoc = $row['currentDoc'];

$doc = $pdo->query("SELECT * FROM document WHERE docId=$currentDoc");
$row = $doc->fetch();
$title = $row['title'];
$urlDoc = "documentL.php?id=$currentDoc";

$delete_url = "delete_patron.php?id=$id";
$url = "get_document.php?id=$id";
$text = "Get document";
unset($_POST);

include ('UserCard.html');

?>