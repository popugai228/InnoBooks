<?php
//authorization for librarian

include_once ('connect_mysql.php');

if (!isset($_POST["login"]) and !isset($_POST["password"])) {

    include ('enterL.html');

}elseif (!strlen($_POST["login"]) or !strlen($_POST["password"])){

    include ('enterL.html');
    echo 'All fields must not be empty';

}else{

    $login = $_POST['login'];
    $pass = md5($_POST['password']);

    $error_message = '';
    $librarian = $pdo->query("SELECT * FROM librarian");
    $row = $librarian->fetch();

    if ($pass == $row['password'] and $login==$row['login']) {
        session_start();
        $_SESSION['user'] = $login;
        include ('libHome.php');
    }else{
        $error_message = 'Your login or password incorrect';
        include ('enterL.html');
    }

}

?>