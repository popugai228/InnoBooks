<?php

include_once ('connect_mysql.php');

$docId = $_GET['id'];

$pdo->query("DELETE FROM `document` WHERE docId=$docId");
$pdo->query("DELETE FROM `copies` WHERE docId=$docId");
$pdo->query("DELETE FROM `queue` WHERE docId=$docId");
$pdo->query("UPDATE `user` SET `returnDate`=0000-00-00 WHERE reservedDoc=$docId");
$pdo->query("UPDATE `user` SET `reservedDoc`=0 WHERE reservedDoc=$docId");
$pdo->query("UPDATE `user` SET `returnDate`=0000-00-00 WHERE currentDoc=$docId");
$pdo->query("UPDATE `user` SET `currentDoc`=0 WHERE currentDoc=$docId");

include ('delete_doc_successful.html');

?>