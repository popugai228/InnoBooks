<?php
//the main page for librarian. File returns buttons: list of users,list of docs, add new user, add new document, list of users with reservation
include_once ('connect_mysql.php');


$user_info = $pdo->query('SELECT * FROM user WHERE reservedDoc <> 0 AND TO_DAYS(NOW()) - TO_DAYS(returnDate) > 1;');


while ($row=$user_info->fetch()){

    $docId = $row['reservedDoc'];
    $userId = $row['cardId'];
    $pdo->query('UPDATE `user` SET `reservedDoc`=0,`returnDate`="0000-00-00" WHERE cardId='.$userId);
    $pdo->query('UPDATE `copies` SET `available`=1 WHERE docId='.$docId.' AND available=0 AND location<>"on hand" LIMIT 1');

    //queue changing
    $queue = $pdo->query("SELECT * FROM queue WHERE docId=$docId");
    if ($row = $queue->fetch()) {

        $priority = $row['priority'];
        while ($row = $queue->fetch()) {
            if ($row['priority'] < $priority)
                $priority = $row['priority'];
        }

        $queue = $pdo->query("SELECT * FROM queue WHERE priority=$priority");
        $row = $queue->fetch();
        $userId = $row['cardId'];
        $pdo->query("UPDATE `user` SET `reservedDoc`=$docId, `returnDate`=DATE_ADD(NOW(),Interval 1 DAY) WHERE cardId=$userId");
        $pdo->query("UPDATE `copies` SET `available`=0 WHERE docId=$docId AND available=1 LIMIT 1");
        $pdo->query("DELETE FROM `queue` WHERE priority=$priority");

        $card = $pdo->query("SELECT * FROM usercard WHERE cardId=$userId");
        $row = $card->fetch();
        $name = $row['name'];
        $surname = $row['surname'];

        $url_text = $name." ".$surname;
        $url = "user_card.php?id=" . $userId;
        include("queue_changes.html");

    }

}


include("libHome.html");

?>