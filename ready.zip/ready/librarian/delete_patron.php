<?php
//deleting user from system


include_once ('connect_mysql.php');

$id = $_GET['id'];

$user_info = $pdo->query('SELECT * FROM user WHERE cardId='.$id);
$row = $user_info->fetch();
$reservedDoc = $row['reservedDoc'];
$currentDoc = $row['currentDoc'];
$returnDate = $row['returnDate'];

if ($currentDoc == 0) {

    $empty_date = strtotime('0000-00-00');
    $condition_date = strtotime($returnDate);

    if ($reservedDoc != 0 and $empty_date != $condition_date) {

        $pdo->query('UPDATE `copies` SET `available`=1 WHERE docId=' . $reservedDoc . ' AND available=0 AND location<>"on hand" LIMIT 1');

        $queue = $pdo->query("SELECT * FROM queue WHERE docId=$reservedDoc");
        if ($row = $queue->fetch()) {

            $priority = $row['priority'];
            while ($row = $queue->fetch()) {
                if ($row['priority'] < $priority)
                    $priority = $row['priority'];
            }

            $queue = $pdo->query("SELECT * FROM queue WHERE priority=$priority");
            $row = $queue->fetch();
            $userId = $row['cardId'];
            $pdo->query("UPDATE `user` SET `reservedDoc`=$reservedDoc, `returnDate`=DATE_ADD(NOW(),Interval 1 DAY) WHERE cardId=$userId");
            $pdo->query("UPDATE `copies` SET `available`=0 WHERE docId=$reservedDoc AND available=1 LIMIT 1");
            $pdo->query("DELETE FROM `queue` WHERE priority=$priority");

            $card = $pdo->query("SELECT * FROM usercard WHERE cardId=$userId");
            $row = $card->fetch();
            $name = $row['name'];
            $surname = $row['surname'];

            $url_text = $name . " " . $surname;
            $url = "user_card.php?id=" . $userId;
            include("queue_changes.html");
        }


    }

    $pdo->query("DELETE FROM `user` WHERE cardId=$id");
    $pdo->query("DELETE FROM `queue` WHERE cardId=$id");
    $pdo->query("DELETE FROM `usercard` WHERE cardId=$id");

    include('delete_patron_succesfull.html');



} else {
    include ('delete_patron_error.html');
}

?>