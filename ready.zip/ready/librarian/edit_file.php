<?php
//page that puts the book into database

include "connect_mysql.php";
$sequence_of_fields=[];
$query ="";
$id = $_GET["id"];

if (!isset($_POST["title"]) and !isset($_POST["authors"])
    and !isset($_POST["price"])) {
    include_once "edit_file.html";
}
else
{
    if($_POST["title"]!="")
    {
        $sequence_of_fields["title"] = $_POST["title"];
    }
    if($_POST["authors"]!="")
    {
        $sequence_of_fields["authors"] = $_POST["authors"];
    }

    if($_POST["price"]!="")
    {
        $sequence_of_fields["price"] = $_POST["price"];
    }
    $query="UPDATE `document` SET";
    foreach($sequence_of_fields as $key => $value)
    {
        $query=$query."`$key`=\"$value\", ";
    }
    $query=substr($query,0,-2)." WHERE docId=$id";
    $pdo->query($query);
    include ("av_list.php");


}


?>
