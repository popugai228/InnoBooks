<?php
//when patron reserved a document, librarian runs this file and in database puts info that user checked out the document

include_once ('connect_mysql.php');


$userid = $_GET['id'];

$user = $pdo->query("select * from user where cardid=$userid");
$row = $user->fetch();
$docid = $row['reservedDoc'];


$pdo->query("update `user` set `reservedDoc`=0 where cardid=$userid");

$user = $pdo->query("select * from usercard where cardid=$userid");
$row = $user->fetch();
$usertype = $row['userType'];

$doc = $pdo->query("select * from document where docid=$docid");
$row = $doc->fetch();

$count = 0;
$queue = $pdo->query("select * from queue where docid=$docid");
while ($queue->fetch())
    $count += 1;



if ($usertype == 1) {
    $pdo->query('update `user` set `returndate`=date_add(now(),interval 28 day) where cardid='.$userid);
} elseif ($count == 0) {
    $pdo->query('update `user` set `returndate`=date_add(now(),interval 21 day) where cardid='.$userid);
} else {
    $pdo->query('update `user` set `returndate`=date_add(now(),interval 14 day) where cardid='.$userid);
}

$text = 'on hand';
$pdo->query('update `copies` set `location`="'.$text.'" where docId='.$docid.' AND location!="'.$text.'" AND available=0 LIMIT 1');

$pdo->query("update `user` set `currentDoc`=$docid where cardId=$userid");

$data = $pdo->query("select * from user where cardid=$userid");
$row = $data->fetch();
$date = $row['returnDate'];

include('give_successful.html');


?>