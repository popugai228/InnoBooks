-- phpMyAdmin SQL Dump
-- version 4.7.7
-- https://www.phpmyadmin.net/
--
-- Хост: localhost
-- Время создания: Фев 04 2018 г., 19:21
-- Версия сервера: 10.1.30-MariaDB
-- Версия PHP: 7.2.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `itp`
--

-- --------------------------------------------------------

--
-- Структура таблицы `copies`
--

CREATE TABLE `copies` (
  `docId` int(11) NOT NULL,
  `location` text NOT NULL,
  `available` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Дамп данных таблицы `copies`
--

INSERT INTO `copies` (`docId`, `location`, `available`) VALUES
(1, 'secon room', 1),
(2, 'where', 1),
(3, 'efsd', 1),
(4, 'dxfs', 1),
(5, 'fdsggf', 1);

-- --------------------------------------------------------

--
-- Структура таблицы `document`
--

CREATE TABLE `document` (
  `docId` int(11) NOT NULL,
  `title` text NOT NULL,
  `authors` text NOT NULL,
  `edition` text NOT NULL,
  `publicationDate` date NOT NULL,
  `publishedBy` text NOT NULL,
  `documentType` tinyint(4) NOT NULL,
  `isAvailable` tinyint(4) NOT NULL,
  `price` int(11) NOT NULL,
  `issueAuthors` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Дамп данных таблицы `document`
--

INSERT INTO `document` (`docId`, `title`, `authors`, `edition`, `publicationDate`, `publishedBy`, `documentType`, `isAvailable`, `price`, `issueAuthors`) VALUES
(1, 'Touch of Ananas', 'Bertrand Meyer', '4th', '2002-04-12', 'OOO Something', 1, 1, 3900, ''),
(2, 'Lovely bones', 'Alice Sebold', '1st', '2002-12-12', 'Little, Brown and Company', 1, 1, 325, ''),
(3, 'Discret math', 'Rosen', '3rd', '2000-12-12', 'some company', 1, 1, 3440, ''),
(4, 'some article\r\n', 'some arthors', '1', '0000-00-00', 'some magazine', 2, 1, 324, 'I don\'t know what is it'),
(5, 'Cute song', 'help me!', '', '0000-00-00', '', 4, 1, 432, '');

-- --------------------------------------------------------

--
-- Структура таблицы `librarian`
--

CREATE TABLE `librarian` (
  `login` text NOT NULL,
  `password` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Дамп данных таблицы `librarian`
--

INSERT INTO `librarian` (`login`, `password`) VALUES
('admin', '75e295b002791ed4f97f7171b5cbf1da');

-- --------------------------------------------------------

--
-- Структура таблицы `queue`
--

CREATE TABLE `queue` (
  `docId` int(11) NOT NULL,
  `cardId` int(11) NOT NULL,
  `priority` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Структура таблицы `user`
--

CREATE TABLE `user` (
  `cardId` int(11) NOT NULL,
  `currentDoc` int(11) NOT NULL,
  `returnDate` date NOT NULL,
  `fine` int(11) NOT NULL,
  `reservedDoc` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Дамп данных таблицы `user`
--

INSERT INTO `user` (`cardId`, `currentDoc`, `returnDate`, `fine`, `reservedDoc`) VALUES
(1, 0, '2018-03-03', 0, 0),
(2, 0, '2018-03-03', 0, 0),
(3, 0, '2018-03-03', 0, 0);

-- --------------------------------------------------------

--
-- Структура таблицы `usercard`
--

CREATE TABLE `usercard` (
  `cardId` int(11) NOT NULL,
  `password` text NOT NULL,
  `email` text NOT NULL,
  `phone` text NOT NULL,
  `name` text NOT NULL,
  `surname` text NOT NULL,
  `userType` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Дамп данных таблицы `usercard`
--

INSERT INTO `usercard` (`cardId`, `password`, `email`, `phone`, `name`, `surname`, `userType`) VALUES
(1, 'd8578edf8458ce06fbc5bb76a58c5ca4', 'v.bahteev@innopolis.ru', '89373181913', 'Vlad', 'Bakhteev', 0),
(2, '202cb962ac59075b964b07152d234b70', 'mail@innopolis.ru', '82183217128', 'Alex', 'Smirnov', 1),
(3, '7815696ecbf1c96e6894b779456d330e', 'some_mail', '37432843232', 'Banan', 'Bananov', 0);

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `document`
--
ALTER TABLE `document`
  ADD PRIMARY KEY (`docId`);

--
-- Индексы таблицы `queue`
--
ALTER TABLE `queue`
  ADD PRIMARY KEY (`priority`);

--
-- Индексы таблицы `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`cardId`);

--
-- Индексы таблицы `usercard`
--
ALTER TABLE `usercard`
  ADD PRIMARY KEY (`cardId`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `document`
--
ALTER TABLE `document`
  MODIFY `docId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT для таблицы `queue`
--
ALTER TABLE `queue`
  MODIFY `priority` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT для таблицы `user`
--
ALTER TABLE `user`
  MODIFY `cardId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT для таблицы `usercard`
--
ALTER TABLE `usercard`
  MODIFY `cardId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
