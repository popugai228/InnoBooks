# InnoBooks
 To start, you need to install xampp. 
 You need to put itp.sql into your database.
 Turn on apache and MySQL.  
 Then in the configs.php write the password from your database. 
 In the browser run the link: localhost/authorization.php
 login for librarian is: "admin"
 password for librarian is: "privetandrey"
