<?php
//return information about document

include_once ('connect_mysql.php');

$id = $_GET['id'];

//делаю запрос в БД
$doc_info = $pdo->query("SELECT * FROM document WHERE docId=$id");
$row = $doc_info->fetch();

//создаю переменные для вывода в html файл
$docId = $row['docId'];
$title = $row['title'];
$authors = $row['authors'];
$publicationDate = $row['publicationDate'];
$publishedBy = $row['publishedBy'];
$documentType = $row['documentType'];
$isAvailable = $row['isAvailable'];

$copies = $pdo->query("SELECT * FROM copies WHERE available=1 AND docId=$docId");
$count = 0;
while ($row = $copies->fetch())
    $count = $count + 1;

//вывожу html файл
$url = 'reserve.php?id='.$id;

include('document.html');


?>