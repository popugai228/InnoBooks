<?php
//main page for user with button: list of documents

include ('userHome.html');

?>