<?php
//return list of documents

unset($_POST);
include_once ('connect_mysql.php');



$card_info = $pdo->query('SELECT * FROM document');

while ($row = $card_info->fetch()){

    $docId = $row['docId'];
    $url = "document.php?id=".$docId;
    $url_text = $row['title'];

    include ('doc_link.html');

}


?>