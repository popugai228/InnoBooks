<?php
include_once ("connect_mysql.php");
session_start();
$id = $_SESSION["userId"];


$fine_calc = $pdo->query("SELECT * FROM user WHERE currentDoc <> 0 AND TO_DAYS(NOW()) - TO_DAYS(returnDate) > 1 AND cardId=$id");
if ($row = $fine_calc->fetch()){
    $doc = $row['currentDoc'];
    $date = strtotime($row['returnDate']);
    $now = time();

    $date_diff = $now - $date;
    $day_diff = round($date_diff / (60 * 60 * 24));

    $document = $pdo->query("SELECT * FROM document WHERE docId=$doc");
    $doc_row = $document->fetch();
    $price = $doc_row['price'];

    $fine = $day_diff * 100;
    if ($price < $fine) {
        $fine = $price;
    }

    $pdo->query("UPDATE `user` SET `fine`=$fine WHERE cardId=$id");
}


$user = $pdo->query("SELECT * FROM `user` WHERE cardId=$id");
$row = $user->fetch();

$fine = $row["fine"];
$returnDate = $row["returnDate"];
$currentDoc = $row["currentDoc"];
if ($currentDoc == 0) $returnDate = "";
$doc_link = "document.php?id=$currentDoc";

$card = $pdo->query("SELECT * FROM `usercard` WHERE cardId=$id");
$row = $card->fetch();

$name = $row['name'];
$surname = $row['surname'];

$document = $pdo->query("SELECT * FROM `document` WHERE docId=$currentDoc");
$row = $document->fetch();
$title = $row['title'];

include_once ("account.html");

?>