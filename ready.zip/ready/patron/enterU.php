<?php
//authorization for users

include ('connect_mysql.php');
$error_message = "";

if (!isset($_POST["id"]) and !isset($_POST["password"])) {

    include ('enterU.html');

}elseif (!strlen($_POST["id"]) or !strlen($_POST["password"])){

    include ('enterU.html');
    echo 'All fields must not be empty';

}else{

    $id = $_POST['id'];
    $pass = md5($_POST['password']);

    $error_message = '';
    $usercard = $pdo->query("SELECT * FROM usercard WHERE cardId=".$id);

    if ($row = $usercard->fetch()) {
        if ($pass == $row['password']) {
            session_start();
            $_SESSION['userId'] = $id;
            include('userHome.php');
        } else {
            $error_message = 'Your login or password incorrect';
            include('enterU.html');
        }
    } else {
        $error_message = 'This id does not exist';
        include "enterU.html";
    }

}

?>