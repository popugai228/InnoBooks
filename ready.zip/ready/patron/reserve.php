<?php
//this file allows to patron reserve some document if it is available or take the queue

include_once ('connect_mysql.php');

session_start();
$userId = $_SESSION['userId'];


$docId = $_GET['id'];

$doc_info = $pdo->query("SELECT * FROM document WHERE docId=$docId");

if ($row = $doc_info->fetch()) {    // delete this if!!!!!!!
    $isAvailable = $row['isAvailable'];
    $title = $row['title'];

    $user_info = $pdo->query("SELECT * FROM user WHERE cardId=$userId");
    $row = $user_info->fetch();
    $fine = $row['fine'];
    $currentDoc = $row['currentDoc'];
    $reservedDoc = $row['reservedDoc'];

    //count of available copies
    $copies = $pdo->query("SELECT * FROM copies WHERE available=1 AND docId=$docId");
    $count = 0;
    while ($row = $copies->fetch())
        $count = $count + 1;


    if ($fine == 0 and $currentDoc == 0 and $reservedDoc == 0 and $count > 0 and $isAvailable == 1) {
        //получить бронь
        $pdo->query("UPDATE `user` SET `reservedDoc`=$docId WHERE cardId=$userId");
        $pdo->query("UPDATE `copies` SET `available`=0 WHERE docId=$docId AND available=1 LIMIT 1");
        $pdo->query("UPDATE `user` SET `returnDate`=DATE_ADD(NOW(),Interval 1 DAY) WHERE cardId=".$userId);

        include('reserved.html');

    } elseif (($fine > 0 or $currentDoc != 0 or $reservedDoc != 0) and $isAvailable == 1) {

        $text = "ERROR! You have an uncommitted document or unpaid fine!";
        include('not_available.html');

    } elseif ($isAvailable == 1 and $count == 0) {

        //встать в очередь
        $pdo->query("UPDATE `user` SET `reservedDoc`=$docId WHERE cardId=$userId");
        $pdo->query("INSERT INTO `queue`(`docId`, `cardId`) VALUES ($docId,$userId)");

        $text = "you successfully took the queue";
        include('not_available.html');

    } else {

        $text = "Document is not available";
        include('not_available.html');

    }

} else echo "this book doesn't exist"; // delete this



?>